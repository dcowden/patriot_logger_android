package com.patriotlogger.logger.test;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;

import com.patriotlogger.logger.data.Repository;
import com.patriotlogger.logger.data.Setting;
import com.patriotlogger.logger.data.TagData;
import com.patriotlogger.logger.data.TagStatus;
import com.patriotlogger.logger.data.TagStatus.TagStatusState;
import com.patriotlogger.logger.logic.RssiData;
import com.patriotlogger.logger.logic.SampleProcessor;
import com.patriotlogger.logger.logic.SimpleEmaPeakHandler;
import com.patriotlogger.logger.logic.TagPeakFinder;
import com.patriotlogger.logger.logic.filters.MinMaxRssiFilter;
import com.patriotlogger.logger.logic.filters.RssiFilter;
import com.patriotlogger.logger.logic.RssiHandler;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;

/**
 * Rewritten to mirror the real pipeline and capture MULTIPLE passes.
 * JSON now contains:
 *   algorithms[ALGO].tracks[trackId].APPROACHINGS/HERES/LOGGEDS/PEAKS (arrays)
 * plus legacy singletons algorithms[ALGO].APPROACHING/HERE/LOGGED/PEAK for back-compat,
 * and "line" with the handler's internal value trace.
 */
@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE, sdk = 34)
public class DriverMain {

    private static final String SAMPLES_DIR = "data_samples";
    private static final long BASE_TS = 1761170000000L;

    // candidate field names to reflect handler's current filtered value
    private static final String[] VALUE_FIELDS = new String[]{
            "ema", "median", "filtered", "filter", "estimate", "est", "smoothed", "value", "stateRssi", "x", "xhat"
    };

    @Test
    public void runDriver() throws Exception {
        main(new String[]{});
    }

    public static void main(String[] args) throws Exception {
        // ---------- Build list of CSV resources ----------
        List<String> resourceFiles = listResourceFiles(SAMPLES_DIR);
        if (resourceFiles.isEmpty()) {
            System.out.println("No CSV files found under src/test/resources/" + SAMPLES_DIR);
            return;
        }

        // ---------- Define algorithm variants via Setting (mirrors service handler sweep) ----------
        List<Setting> algos = new ArrayList<>();

        Setting a = new Setting();
        a.tca_alpha = 0.30f; a.tx_power_at_1m_dbm = -70.0; a.path_loss_n = 2.0;
        a.tca_here_meters = 1.0; a.tca_threshold_sec = 1.5;
        a.tca_window_size = 40;  a.tca_min_points = 6; a.tca_approach_meters = 15.0;
        a.filter_min_rssi = -115; a.filter_max_rssi = -35;
        algos.add(a);
        List<SampleProcessor> processors = new ArrayList<>();

//        {
//            Setting a = new Setting();
//            a.tca_alpha = 0.30f; a.tx_power_at_1m_dbm = -70.0; a.path_loss_n = 2.0;
//            a.tca_here_meters = 4.0; a.tca_threshold_sec = 1.5;
//            a.tca_window_size = 40;  a.tca_min_points = 6; a.tca_approach_meters = 12.0;
//            a.filter_min_rssi = -115; a.filter_max_rssi = -35;
//            algos.add(a);
//        }

        // ---------- Process each CSV ----------
        for (String resPath : resourceFiles) {
            final String sampleFile = resPath.substring(resPath.lastIndexOf('/') + 1);

            List<RssiData> raw = readSamplesFromResource(resPath);
            List<RssiData> samples = applyFilters(raw, Arrays.asList(new MinMaxRssiFilter(-115, -35)));

            // Raw filtered series for plotting (blue circles)
            Map<Long, Integer> tsToRssi = new HashMap<>(Math.max(16, samples.size() * 2));
            List<Long> tsList = new ArrayList<>(samples.size());
            for (RssiData s : samples) {
                tsToRssi.put(s.timestampMs, s.rssi);
                tsList.add(s.timestampMs);
            }
            Collections.sort(tsList);

            // Results per algorithm
            List<AlgoResult> algoResults = new ArrayList<>();

            for (Setting algoSetting : algos) {
                // Fresh in-memory DB per algorithm to avoid cross-contamination
                Context ctx = ApplicationProvider.getApplicationContext();
                Repository repo = Repository.createInMemoryForTest(ctx);

                final Setting[] current = new Setting[]{ cloneSetting(algoSetting) };
                SimpleEmaPeakHandler sph = new SimpleEmaPeakHandler(0.1f, -87, 3, 5000,30000);

                SampleProcessor proc = new SampleProcessor(repo, sph,a);


                // Trace of handler internal value (best effort)
                List<LinePoint> line = new ArrayList<>(samples.size());

                // Track state transitions per trackId
                Map<Integer, List<StateHit>> hitsByTrack = new LinkedHashMap<>();
                // Keep last state per trackId to detect transitions
                Map<Integer, TagStatusState> prevByTrack = new HashMap<>();

                // Process stream
                for (RssiData s : samples) {
                    TagStatus cur = proc.processSample(s.tagId, s.rssi, s.timestampMs);

                    int trackId = cur.trackId;
                    TagStatusState prev = prevByTrack.getOrDefault(trackId, TagStatusState.TOO_FAR);

                    // reflect handler internal value (if any), else raw RSSI
                    double v = s.rssi;
                    RssiHandler h = proc.getHandlerForTrack(trackId);
                    if (h != null) {
                        Double maybe = reflectCurrentValue(h);
                        if (maybe != null) v = maybe;
                    }
                    line.add(new LinePoint(s.timestampMs - BASE_TS, v));

                    // record EVERY interesting transition
                    if (cur.state != prev) {
                        if (cur.state == TagStatusState.APPROACHING ||
                                cur.state == TagStatusState.HERE ||
                                cur.state == TagStatusState.LOGGED) {
                            hitsByTrack.computeIfAbsent(trackId, k -> new ArrayList<>())
                                    .add(new StateHit(s.timestampMs, trackId, cur.state));
                        }
                        prevByTrack.put(trackId, cur.state);
                    }
                }

                // Convert transitions to points per track, and compute PEAKS per pass window
                Map<Integer, List<Point>> approachesByTrack = new LinkedHashMap<>();
                Map<Integer, List<Point>> heresByTrack      = new LinkedHashMap<>();
                Map<Integer, List<Point>> loggedsByTrack    = new LinkedHashMap<>();
                Map<Integer, List<Point>> peaksByTrack      = new LinkedHashMap<>();

                for (Map.Entry<Integer, List<StateHit>> e : hitsByTrack.entrySet()) {
                    final int trackId = e.getKey();
                    List<StateHit> hits = e.getValue();

                    // States → Point arrays
                    for (StateHit hit : hits) {
                        Point p = pointForState(Long.toString(hit.ts), tsToRssi, tsList);
                        switch (hit.state) {
                            case APPROACHING:
                                approachesByTrack.computeIfAbsent(trackId, k -> new ArrayList<>()).add(p); break;
                            case HERE:
                                heresByTrack.computeIfAbsent(trackId, k -> new ArrayList<>()).add(p); break;
                            case LOGGED:
                                loggedsByTrack.computeIfAbsent(trackId, k -> new ArrayList<>()).add(p); break;
                        }
                    }

                    // Compute peaks for each LOGGED segment (from previous LOGGED or stream start to this LOGGED)
                    List<Point> peaks = new ArrayList<>();
                    Long lastCut = null;
                    for (StateHit hit : hits) {
                        if (hit.state == TagStatusState.LOGGED) {
                            long hi = hit.ts;
                            long lo = (lastCut != null) ? lastCut : (samples.isEmpty() ? BASE_TS : samples.get(0).timestampMs);

                            List<RssiData> window = new ArrayList<>();
                            for (RssiData s : samples) {
                                if (s.timestampMs >= lo && s.timestampMs <= hi) window.add(s);
                                if (s.timestampMs > hi) break;
                            }
                            String tPeak = detectPeakTs(window);
                            Point pPeak = pointForState(tPeak, tsToRssi, tsList);
                            peaks.add(pPeak);
                            lastCut = hi;
                        }
                    }
                    if (!peaks.isEmpty()) peaksByTrack.put(trackId, peaks);
                }

                // Legacy first occurrences for back-compat plots
                Point firstApproach = null, firstHere = null, firstLogged = null, firstPeak = null;
                for (Integer trackId : new TreeSet<>(hitsByTrack.keySet())) {
                    if (firstApproach == null) {
                        List<Point> A = approachesByTrack.get(trackId);
                        if (A != null && !A.isEmpty()) firstApproach = A.get(0);
                    }
                    if (firstHere == null) {
                        List<Point> H = heresByTrack.get(trackId);
                        if (H != null && !H.isEmpty()) firstHere = H.get(0);
                    }
                    if (firstLogged == null) {
                        List<Point> L = loggedsByTrack.get(trackId);
                        if (L != null && !L.isEmpty()) firstLogged = L.get(0);
                    }
                    if (firstPeak == null) {
                        List<Point> P = peaksByTrack.get(trackId);
                        if (P != null && !P.isEmpty()) firstPeak = P.get(0);
                    }
                }

                String algoName = sph + "";
                algoResults.add(new AlgoResult(
                        algoName, line,
                        approachesByTrack, heresByTrack, loggedsByTrack, peaksByTrack,
                        firstApproach, firstHere, firstLogged, firstPeak));
            }

            // Write JSON
            String json = buildJson(sampleFile, samples, algoResults);
            Path out = Paths.get("result_" + sampleFile + ".json");
            try (BufferedWriter bw = Files.newBufferedWriter(out,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING)) {
                bw.write(json);
            }
            System.out.println("Wrote " + out.toAbsolutePath());
        }

        System.out.println("Done. Plot with plot_results_lines.py");
    }

    // ---------- Helpers & data structures ----------

    private static class StateHit {
        final long ts; final int trackId; final TagStatusState state;
        StateHit(long ts, int trackId, TagStatusState state){ this.ts=ts; this.trackId=trackId; this.state=state; }
    }
    private static class Point { final Long tsOffset; final Integer rssi; Point(Long t, Integer r){ tsOffset=t; rssi=r; } }
    private static class LinePoint { final long t; final double v; LinePoint(long t,double v){ this.t=t; this.v=v; } }

    private static class AlgoResult {
        final String name;
        final List<LinePoint> line;
        final Map<Integer, List<Point>> approachesByTrack;
        final Map<Integer, List<Point>> heresByTrack;
        final Map<Integer, List<Point>> loggedsByTrack;
        final Map<Integer, List<Point>> peaksByTrack;
        final Point firstApproach, firstHere, firstLogged, firstPeak;

        AlgoResult(String name,
                   List<LinePoint> line,
                   Map<Integer, List<Point>> A,
                   Map<Integer, List<Point>> H,
                   Map<Integer, List<Point>> L,
                   Map<Integer, List<Point>> P,
                   Point fA, Point fH, Point fL, Point fP) {
            this.name = name;
            this.line = line;
            this.approachesByTrack = A;
            this.heresByTrack = H;
            this.loggedsByTrack = L;
            this.peaksByTrack = P;
            this.firstApproach = fA;
            this.firstHere = fH;
            this.firstLogged = fL;
            this.firstPeak = fP;
        }
    }

    private static float nz(Float f, float d) { return (f != null) ? f : d; }
    private static double nz(Double d, double def) { return (d != null) ? d : def; }
    private static int nz(Integer v, int def) { return (v != null) ? v : def; }

    private static Double reflectCurrentValue(Object handler) {
        Class<?> c = handler.getClass();
        for (String name : VALUE_FIELDS) {
            try {
                Field f = findField(c, name);
                if (f != null) {
                    f.setAccessible(true);
                    Object v = f.get(handler);
                    if (v instanceof Number) return ((Number) v).doubleValue();
                }
            } catch (Throwable ignore) { /* try next */ }
        }
        return null;
    }
    private static Field findField(Class<?> c, String name) {
        Class<?> cur = c;
        while (cur != null) {
            try { return cur.getDeclaredField(name); }
            catch (NoSuchFieldException e) { cur = cur.getSuperclass(); }
        }
        return null;
    }

    private static List<RssiData> applyFilters(List<RssiData> in, List<RssiFilter> filters) {
        if (filters == null || filters.isEmpty()) return in;
        List<RssiData> out = new ArrayList<>(in.size());
        outer:
        for (RssiData s : in) {
            for (RssiFilter f : filters) {
                if (!f.shouldAccept(s.timestampMs, s.rssi)) continue outer;
            }
            out.add(s);
        }
        return out;
    }

    private static String detectPeakTs(List<RssiData> samples) {
        if (samples == null || samples.isEmpty()) return "X";
        try {
            List<TagData> tagDataList = new ArrayList<>(samples.size());
            for (RssiData s : samples) tagDataList.add(new TagData(0, s.timestampMs, s.rssi));
            Setting setting = new Setting();
            setting.rssi_averaging_alpha = 0.30f;
            TagPeakFinder pf = new TagPeakFinder();
            Object peakData = pf.findPeak(tagDataList, setting);
            if (peakData == null) return "X";
            Long ts = getLongIfExists(peakData, "peakTimeMs");
            if (ts == null) ts = getLongIfExists(peakData, "timestampMs");
            return (ts == null) ? "X" : Long.toString(ts);
        } catch (Throwable t) { return "X"; }
    }

    private static Long getLongIfExists(Object obj, String field) {
        try {
            Field f = obj.getClass().getDeclaredField(field);
            f.setAccessible(true);
            Object v = f.get(obj);
            if (v instanceof Long) return (Long) v;
            if (v instanceof Number) return ((Number) v).longValue();
            return null;
        } catch (Throwable t) { return null; }
    }

    private static Point pointForState(String tsStr, Map<Long, Integer> tsToRssi, List<Long> sortedTs) {
        if (tsStr == null || tsStr.equals("X")) return new Point(null, null);
        Long ts;
        try { ts = Long.parseLong(tsStr); } catch (NumberFormatException e) { return new Point(null, null); }
        Integer rssi = tsToRssi.get(ts);
        if (rssi == null && !sortedTs.isEmpty()) {
            int idx = Collections.binarySearch(sortedTs, ts);
            if (idx < 0) {
                int ins = -idx - 1;
                long bestTs;
                if (ins <= 0) bestTs = sortedTs.get(0);
                else if (ins >= sortedTs.size()) bestTs = sortedTs.get(sortedTs.size() - 1);
                else {
                    long t1 = sortedTs.get(ins - 1), t2 = sortedTs.get(ins);
                    bestTs = (Math.abs(ts - t1) <= Math.abs(ts - t2)) ? t1 : t2;
                }
                rssi = tsToRssi.get(bestTs);
                ts = bestTs;
            }
        }
        Long tOff = (rssi == null) ? null : (ts - BASE_TS);
        return new Point(tOff, rssi);
    }

    private static String buildJson(String sampleFile, List<RssiData> samples, List<AlgoResult> algoResults) {
        StringBuilder sb = new StringBuilder(256_000);
        sb.append("{");
        sb.append("\"sampleFile\":").append(q(sampleFile)).append(",");
        sb.append("\"baseTs\":").append(BASE_TS).append(",");

        // raw series
        sb.append("\"series\":[");
        for (int i = 0; i < samples.size(); i++) {
            RssiData s = samples.get(i);
            sb.append("{\"t\":").append(s.timestampMs - BASE_TS)
                    .append(",\"rssi\":").append(s.rssi).append("}");
            if (i + 1 < samples.size()) sb.append(",");
        }
        sb.append("],");

        // algorithms block
        sb.append("\"algorithms\":{");
        for (int ai = 0; ai < algoResults.size(); ai++) {
            AlgoResult ar = algoResults.get(ai);
            if (ai > 0) sb.append(",");
            sb.append(q(ar.name)).append(":{");

            // tracks -> arrays per state
            sb.append("\"tracks\":{");
            int tcount = 0;
            for (Integer trackId : new TreeSet<>(unionKeys(ar.approachesByTrack, ar.heresByTrack, ar.loggedsByTrack, ar.peaksByTrack))) {
                if (tcount++ > 0) sb.append(",");
                sb.append(q(String.valueOf(trackId))).append(":{");
                List<Point> A = ar.approachesByTrack.getOrDefault(trackId, Collections.emptyList());
                List<Point> H = ar.heresByTrack.getOrDefault(trackId, Collections.emptyList());
                List<Point> L = ar.loggedsByTrack.getOrDefault(trackId, Collections.emptyList());
                List<Point> P = ar.peaksByTrack.getOrDefault(trackId, Collections.emptyList());
                sb.append("\"APPROACHINGS\":").append(pointsJson(A)).append(",");
                sb.append("\"HERES\":").append(pointsJson(H)).append(",");
                sb.append("\"LOGGEDS\":").append(pointsJson(L)).append(",");
                sb.append("\"PEAKS\":").append(pointsJson(P));
                sb.append("}");
            }
            sb.append("},");

            // legacy singletons for back-compat
            sb.append("\"APPROACHING\":").append(pointJson(ar.firstApproach)).append(",");
            sb.append("\"HERE\":").append(pointJson(ar.firstHere)).append(",");
            sb.append("\"LOGGED\":").append(pointJson(ar.firstLogged)).append(",");
            sb.append("\"PEAK\":").append(pointJson(ar.firstPeak)).append(",");

            // line series
            sb.append("\"line\":[");
            for (int i2 = 0; i2 < ar.line.size(); i2++) {
                LinePoint lp = ar.line.get(i2);
                sb.append("{\"t\":").append(lp.t).append(",\"v\":").append(fmt(lp.v)).append("}");
                if (i2 + 1 < ar.line.size()) sb.append(",");
            }
            sb.append("]}");
        }
        sb.append("}");

        sb.append("}");
        return sb.toString();
    }

    private static Set<Integer> unionKeys(Map<Integer, ?>... maps) {
        Set<Integer> out = new HashSet<>();
        for (Map<Integer, ?> m : maps) if (m != null) out.addAll(m.keySet());
        return out;
    }

    private static String pointJson(Point p) {
        if (p == null || p.tsOffset == null || p.rssi == null) return "{\"t\":null,\"rssi\":null}";
        return "{\"t\":" + p.tsOffset + ",\"rssi\":" + p.rssi + "}";
    }

    private static String pointsJson(List<Point> pts) {
        StringBuilder sb = new StringBuilder(64 + 32 * (pts == null ? 0 : pts.size()));
        sb.append("[");
        if (pts != null) {
            for (int i = 0; i < pts.size(); i++) {
                sb.append(pointJson(pts.get(i)));
                if (i + 1 < pts.size()) sb.append(",");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    private static String q(String s) {
        if (s == null) return "null";
        String esc = s.replace("\\", "\\\\").replace("\"", "\\\"");
        return "\"" + esc + "\"";
    }
    private static String fmt(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) return "null";
        return String.format(Locale.US, "%.3f", d);
    }

    private static Setting cloneSetting(Setting s) {
        Setting c = new Setting();
        c.tca_alpha = s.tca_alpha;
        c.tx_power_at_1m_dbm = s.tx_power_at_1m_dbm;
        c.path_loss_n = s.path_loss_n;
        c.tca_here_meters = s.tca_here_meters;
        c.tca_threshold_sec = s.tca_threshold_sec;
        c.tca_window_size = s.tca_window_size;
        c.tca_min_points = s.tca_min_points;
        c.tca_approach_meters = s.tca_approach_meters;
        c.filter_min_rssi = s.filter_min_rssi;
        c.filter_max_rssi = s.filter_max_rssi;
        c.retain_samples = s.retain_samples;
        c.tagdata_flush_ms = s.tagdata_flush_ms;
        c.abandoned_timeout_ms = s.abandoned_timeout_ms;
        c.sweep_interval_ms = s.sweep_interval_ms;
        return c;
    }

    // ---------- Resource loading (works in Robolectric with src/test/resources) ----------
    private static List<RssiData> readSamplesFromResource(String resourcePath) {
        List<RssiData> out = new ArrayList<>();
        try (BufferedReader br = openResourceAsReader(resourcePath)) {
            String line;
            int tsIdx = -1, tagIdx = -1, rssiIdx = -1, smoothIdx = -1;
            // header
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] hdr = line.split(",", -1);
                    for (int i = 0; i < hdr.length; i++) {
                        String h = hdr[i].trim().toLowerCase(Locale.US);
                        if (h.equals("timestamp") || h.equals("timestampms") || h.equals("time") || h.equals("ts")) tsIdx = i;
                        else if (h.equals("tagid") || h.equals("tag") || h.equals("id")) tagIdx = i;
                        else if (h.equals("rssi")) rssiIdx = i;
                        else if (h.equals("smoothedrssi") || h.equals("smoothed") || h.equals("rssi_smooth")) smoothIdx = i;
                    }
                    break;
                }
            }
            if (tsIdx < 0 || rssiIdx < 0) {
                throw new IOException("Expected header with at least timestamp and rssi: " + resourcePath);
            }
            // rows
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",", -1);
                if (parts.length <= Math.max(tsIdx, rssiIdx)) continue;
                try {
                    long ts = Long.parseLong(parts[tsIdx].trim());
                    int rssi = Integer.parseInt(parts[rssiIdx].trim());
                    int tagId = 0;
                    if (tagIdx >= 0 && tagIdx < parts.length && !parts[tagIdx].trim().isEmpty()) {
                        try { tagId = Integer.parseInt(parts[tagIdx].trim()); } catch (NumberFormatException ignore) {}
                    }
                    int smoothed = rssi;
                    if (smoothIdx >= 0 && smoothIdx < parts.length && !parts[smoothIdx].trim().isEmpty()) {
                        try { smoothed = Integer.parseInt(parts[smoothIdx].trim()); } catch (NumberFormatException ignore) {}
                    }
                    out.add(new RssiData(tagId, ts, rssi, smoothed));
                } catch (NumberFormatException ignore) { /* skip */ }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Failed reading " + resourcePath, e);
        }
        return out;
    }

    private static BufferedReader openResourceAsReader(String resourcePath) throws IOException {
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourcePath);
        if (is == null) throw new IOException("Resource not found: " + resourcePath);
        return new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
    }

    private static List<String> listResourceFiles(String folder) throws IOException {
        // This implementation expects your build tool to put resources on the classpath.
        // We enumerate by reading an index file if present; otherwise, you likely have a helper already.
        // If you have ResourceUtils.listResourceFiles, swap this method to call that.
        // Here we assume you have a text file listing resources at folder/_index.txt
        InputStream idx = Thread.currentThread().getContextClassLoader().getResourceAsStream(folder + "/_index.txt");
        if (idx == null) {
            // Fallback: try common test layout via filesystem (useful when running from IDE)
            Path p = Paths.get("src", "test", "resources", folder);
            if (Files.isDirectory(p)) {
                List<String> out = new ArrayList<>();
                try {
                    Files.walk(p, 1).forEach(fp -> {
                        if (Files.isRegularFile(fp) && fp.toString().toLowerCase(Locale.US).endsWith(".csv")) {
                            // convert filesystem path to resource path
                            Path rel = Paths.get("src", "test", "resources").relativize(fp);
                            out.add(rel.toString().replace('\\', '/'));
                        }
                    });
                } catch (IOException e) {
                    // ignore
                }
                return out;
            }
            return Collections.emptyList();
        }
        List<String> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(idx, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    out.add(folder + "/" + line);
                }
            }
        }
        return out;
    }
}
